import React, { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import { ToastProvider } from './contexts/ToastContext';
import ErrorBoundary from './components/common/ErrorBoundary';
import ProtectedRoute from './components/auth/ProtectedRoute';
import LoadingScreen from './components/common/LoadingScreen';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';

// Pages (Lazy Loaded for Route-Level Code Splitting)
const LandingPage = lazy(() => import('./pages/landing/LandingPage'));
const LoginPage = lazy(() => import('./pages/auth/LoginPage'));
const SignupPage = lazy(() => import('./pages/auth/SignupPage'));
const ForgotPasswordPage = lazy(() => import('./pages/auth/ForgotPasswordPage'));
const ResetPasswordPage = lazy(() => import('./pages/auth/ResetPasswordPage'));
const VerifyEmailPage = lazy(() => import('./pages/auth/VerifyEmailPage'));
const AuthCallback = lazy(() => import('./pages/auth/AuthCallback'));
const DashboardPage = lazy(() => import('./pages/dashboard/DashboardPage'));
const HistoryPage = lazy(() => import('./pages/history/HistoryPage'));
const AboutPage = lazy(() => import('./pages/about/AboutPage'));
const PricingPage = lazy(() => import('./pages/pricing/PricingPage'));
const ContactPage = lazy(() => import('./pages/contact/ContactPage'));
const ReportPage = lazy(() => import('./pages/report/ReportPage'));
const SampleReportPage = lazy(() => import('./pages/report/SampleReportPage'));
const NotFoundPage = lazy(() => import('./pages/errors/NotFoundPage'));

/**
 * SiteProof Root Router
 */
function App() {
  return (
    <ErrorBoundary>
      <BrowserRouter>
        <ThemeProvider>
          <AuthProvider>
            <ToastProvider>
              <div className="min-h-screen bg-slate-50 dark:bg-[#080C14] text-slate-900 dark:text-gray-100 font-sans flex flex-col selection:bg-[#00F5A0] selection:text-slate-950 transition-colors duration-300">
                <Navbar />
                <main className="flex-1 pt-24">
                  <Suspense fallback={<LoadingScreen message="Loading page..." />}>
                    <Routes>
                      {/* Public Routes */}
                      <Route path="/" element={<LandingPage />} />
                      <Route path="/about" element={<AboutPage />} />
                      <Route path="/pricing" element={<PricingPage />} />
                      <Route path="/contact" element={<ContactPage />} />
                      <Route path="/sample-report" element={<SampleReportPage />} />

                      {/* Auth Routes */}
                      <Route path="/login" element={<LoginPage />} />
                      <Route path="/signup" element={<SignupPage />} />
                      <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                      <Route path="/reset-password" element={<ResetPasswordPage />} />
                      <Route path="/verify-email" element={<VerifyEmailPage />} />
                      <Route path="/auth/callback" element={<AuthCallback />} />

                      {/* Protected Routes */}
                      <Route path="/dashboard" element={<ProtectedRoute><DashboardPage /></ProtectedRoute>} />
                      <Route path="/history" element={<ProtectedRoute><HistoryPage /></ProtectedRoute>} />
                      <Route path="/report/:reportId" element={<ProtectedRoute><ReportPage /></ProtectedRoute>} />

                      {/* Error Routes */}
                      <Route path="/404" element={<NotFoundPage />} />
                      <Route path="*" element={<Navigate to="/404" replace />} />
                    </Routes>
                  </Suspense>
                </main>
                <Footer />
              </div>
            </ToastProvider>
          </AuthProvider>
        </ThemeProvider>
      </BrowserRouter>
    </ErrorBoundary>
  );
}


export default App;
